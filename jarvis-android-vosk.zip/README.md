# Jarvis (Android) - Vosk wake word
1. GitHub pe repo banao, is folder ki saari files upload/push karo (hidden .github folder samet).
2. Repo -> Actions -> "Build APK" -> run hone do (~5 min). Workflow khud Vosk model download karke app me daal deta hai.
3. Neeche Artifacts se jarvis-apk download karo, zip kholo, app-debug.apk install karo.
4. App kholo: buttons 1 se 4 tak karo, phir START. Pehli baar model setup me 10-30 sec lagte hain.
5. Bolo: "Jarvis ..." (koi AccessKey nahi chahiye).
