package com.jarvis.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Commands {
    private val ALIAS = mapOf(
        "इंस्टाग्राम" to "instagram", "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp",
        "वॉट्सऐप" to "whatsapp", "फेसबुक" to "facebook", "यूट्यूब" to "youtube",
        "गूगल" to "google", "जीमेल" to "gmail", "स्पॉटिफाई" to "spotify", "कैमरा" to "camera"
    )
    private val FILL = setOf(
        "jarvis", "जार्विस", "जारविस", "please", "youtube", "you", "tube", "pe", "par", "ko", "ka", "ki", "ke",
        "kar", "karo", "kr", "do", "de", "chala", "chalao", "play", "search", "kholo", "khol", "open",
        "call", "phone", "subscribe", "laga", "lagao", "sunao", "dikhao", "hai", "kya", "batao", "bata",
        "channel", "video", "song", "gana", "gaana", "on", "the", "to", "a",
        "पे", "पर", "को", "का", "की", "के", "कर", "करो", "दो", "दे", "चला", "चलाओ", "खोलो", "खोल", "कॉल",
        "फोन", "लगा", "लगाओ", "सुनाओ", "दिखाओ", "है", "क्या", "बताओ", "सब्सक्राइब", "चैनल", "वीडियो",
        "गाना", "गाने", "प्ले", "सर्च"
    )

    private fun clean(t: String) =
        t.split(Regex("\\s+")).filter { it.lowercase() !in FILL }.joinToString(" ").trim()

    private fun go(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (e: Exception) {}
    }

    private fun yt(ctx: Context, q: String, channels: Boolean) {
        val url = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8") +
                (if (channels) "&sp=EgIQAg%253D%253D" else "")
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.youtube")
        go(ctx, i)
    }

    private fun contactNumber(ctx: Context, name: String): String? = try {
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) it.getString(1) else null }
    } catch (e: Exception) { null }

    private fun findApp(ctx: Context, name: String): Intent? {
        val pm = ctx.packageManager
        val n = name.lowercase()
        if (n.length < 2) return null
        for (a in pm.getInstalledApplications(0)) {
            val label = pm.getApplicationLabel(a).toString().lowercase()
            if (label.length >= 3 && (label.contains(n) || n.contains(label))) {
                pm.getLaunchIntentForPackage(a.packageName)?.let { return it }
            }
        }
        return null
    }

    fun run(ctx: Context, raw: String, say: (String) -> Unit) {
        var t = raw.lowercase()
        for ((k, v) in ALIAS) t = t.replace(k, v)
        val j = t.indexOf("jarvis")
        if (j >= 0) t = t.substring(j + 6)
        t = t.trim()
        if (t.isEmpty()) { say("Ji boliye"); return }

        val has = { ws: List<String> -> ws.any { t.contains(it) } }

        if (has(listOf("subscribe", "सब्सक्राइब", "सब्स्क्राइब"))) {
            val n = clean(t)
            say("$n ka channel subscribe kar raha hoon")
            JarvisAccessibility.pending = "subscribe"; JarvisAccessibility.pendingAt = System.currentTimeMillis()
            yt(ctx, n, true); return
        }
        if (has(listOf("call", "कॉल", "phone", "फोन", "dial"))) {
            val digits = t.filter { it.isDigit() }
            val num = if (digits.length >= 7) digits else contactNumber(ctx, clean(t))
            if (num == null) { say("Ye contact nahi mila"); return }
            say("Call laga raha hoon")
            go(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num)))); return
        }
        if (has(listOf("time", "samay", "baje", "टाइम", "समय"))) {
            say("Abhi " + SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()) + " hue hain"); return
        }
        if (has(listOf("open", "kholo", "khol", "खोलो", "खोल", "start", "chalu")) && !has(listOf("youtube pe", "play"))) {
            val n = clean(t)
            val app = findApp(ctx, if (n.isEmpty()) t else n)
            if (app != null) { say("Khol raha hoon"); go(ctx, app); return }
        }
        if (has(listOf("play", "chala", "चला", "प्ले", "gana", "गाना", "youtube", "song", "video"))) {
            val n = clean(t)
            if (n.isEmpty()) { findApp(ctx, "youtube")?.let { go(ctx, it) }; return }
            say("$n chala raha hoon")
            JarvisAccessibility.pending = "play"; JarvisAccessibility.pendingAt = System.currentTimeMillis()
            yt(ctx, n, false); return
        }
        val q = clean(t).ifEmpty { t }
        say("Google pe dhoondh raha hoon")
        go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8"))))
    }
}
