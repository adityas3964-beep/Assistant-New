package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class JarvisService : Service() {
    // Wake word: Vosk (offline). Agar "Jarvis" pakadne me dikkat ho to yahan aur spellings jod do.
    private val wakeWords = listOf("jarvis")
    private val grammar = "[\"jarvis\", \"[unk]\"]"

    private var model: Model? = null
    private var vosk: Recognizer? = null
    private var speech: SpeechService? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var busy = false
    private var listening = false
    private var loading = false
    private var destroyed = false
    private val timeout = Runnable { finishListen(null) }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis sun raha hai")
            .setContentText("Bolo: Jarvis ...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN") }
        LibVosk.setLogLevel(LogLevel.WARNINGS)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startWake()
        return START_STICKY
    }

    // ---------- Wake word (Vosk) ----------

    private fun startWake() {
        if (model == null) loadModel() else startWakeListening()
    }

    private fun loadModel() {
        if (loading) return
        loading = true
        Toast.makeText(this, "Jarvis model load ho raha hai...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val dir = File(filesDir, "vosk-model")
                val ok = File(filesDir, "vosk-model.ok")
                if (!ok.exists()) {
                    dir.deleteRecursively()
                    copyAssets("model", dir)
                    ok.writeText("ok")
                }
                val m = Model(dir.absolutePath)
                handler.post {
                    loading = false
                    if (destroyed) { m.close(); return@post }
                    model = m
                    Toast.makeText(this, "Jarvis ready. Bolo: Jarvis", Toast.LENGTH_SHORT).show()
                    startWakeListening()
                }
            } catch (e: Throwable) {
                handler.post {
                    loading = false
                    File(filesDir, "vosk-model.ok").delete()
                    Toast.makeText(this, "Model error: " + e.message, Toast.LENGTH_LONG).show()
                    stopSelf()
                }
            }
        }.start()
    }

    private fun copyAssets(path: String, dest: File) {
        val list = assets.list(path) ?: emptyArray()
        if (list.isEmpty()) {
            try {
                dest.parentFile?.mkdirs()
                assets.open(path).use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
            } catch (e: java.io.FileNotFoundException) {
                dest.mkdirs()
            }
        } else {
            dest.mkdirs()
            for (n in list) copyAssets("$path/$n", File(dest, n))
        }
    }

    private fun startWakeListening() {
        val m = model ?: return
        stopWake()
        try {
            val rec = Recognizer(m, 16000.0f, grammar)
            vosk = rec
            val ss = SpeechService(rec, 16000.0f)
            speech = ss
            ss.startListening(object : org.vosk.android.RecognitionListener {
                override fun onPartialResult(hypothesis: String?) { heard(hypothesis, "partial") }
                override fun onResult(hypothesis: String?) { heard(hypothesis, "text") }
                override fun onFinalResult(hypothesis: String?) {}
                override fun onError(exception: Exception?) {
                    Toast.makeText(this@JarvisService, "Mic error: " + exception?.message, Toast.LENGTH_LONG).show()
                }
                override fun onTimeout() {}
            })
        } catch (e: Exception) {
            Toast.makeText(this, "Wake word error: " + e.message, Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun stopWake() {
        try { speech?.cancel(); speech?.shutdown() } catch (e: Exception) {}
        speech = null
        try { vosk?.close() } catch (e: Exception) {}
        vosk = null
    }

    private fun heard(json: String?, field: String) {
        if (busy || json == null) return
        val t = try { JSONObject(json).optString(field) } catch (e: Exception) { "" }
        if (wakeWords.any { t.contains(it, ignoreCase = true) }) handler.post { onWake() }
    }

    // ---------- Command flow ----------

    private fun say(t: String) { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j") }

    private fun onWake() {
        if (busy) return
        busy = true
        stopWake()
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150) } catch (e: Exception) {}
        handler.postDelayed({ listen() }, 450)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech service nahi mila"); resume(); return
        }
        val lang = getSharedPreferences("jarvis", MODE_PRIVATE).getString("lang", "hi-IN")
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        listening = true
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(e: Int) { finishListen(null) }
            override fun onResults(res: Bundle?) {
                finishListen(res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        r.startListening(i)
        handler.postDelayed(timeout, 12000)
    }

    private fun finishListen(text: String?) {
        if (!listening) return
        listening = false
        handler.removeCallbacks(timeout)
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
        if (!text.isNullOrBlank()) Commands.run(this, text) { say(it) }
        handler.postDelayed({ resume() }, 3000)
    }

    private fun resume() {
        if (destroyed) return
        busy = false
        startWake()
    }

    override fun onDestroy() {
        destroyed = true
        handler.removeCallbacksAndMessages(null)
        stopWake()
        try { model?.close() } catch (e: Exception) {}
        model = null
        try { recognizer?.destroy() } catch (e: Exception) {}
        tts?.shutdown()
        super.onDestroy()
    }
}
